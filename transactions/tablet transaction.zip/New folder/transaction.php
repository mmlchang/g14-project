<?php include "./db/db.php"; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Tze Yin Membership Management Portal</title>
    <link rel="stylesheet" href="./fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="./styles/style.css" />
</head>

<body>
    
    <?php include "./partial/header.php"; ?>

    <div class="main">

        <div class="header-section">
            <h2 class="heading">Transactions</h2>
            <p class="text">Select Your Transaction Type</p>
            <a href="./tablet-transaction.php" class="button button-primary" style="margin-top: 20px;">Tablet Transaction</a>
            <a href="./blessing-lantren-transaction.php" class="button button-primary" style="margin-top: 20px;">Blessing Lantern Transaction</a>
            <a href="./gaung-ming-lantern-transaction.php" class="button button-primary" style="margin-top: 20px;">Guang-Ming Lantern Transaction</a>
        </div>

        
   
    </div>
  
    <script src="./js/jquery-3.2.1.min.js"></script>
    
</body>

</html>