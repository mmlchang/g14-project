<?php

session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_MMS";
$conn = new mysqli($servername, $username, $password, $dbname);



