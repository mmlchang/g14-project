<header class="header">
    <div class="container">
        <div class="row">
            <a href="./index.php"><img style="float: left;" width="80" src="./images/logo.png" alt=""></a>
            <div class="col-xs-12 height__100P">
                <nav class="navigation height__100P">
                    <span>
                        <i data-toggle="navigation-menu" class="navigation__bars fa fa-bars"></i>
                    </span>

                    <ul class="navigation__items ">
                        <li ><a href="./membership.php">Membership</a></li>
                        <li><a href="./transaction.php">Transaction</a></li>
                        <li><a href="#">Product</a></li>
                        <li><a href="#">Stock</a></li>
                        <li class=""><a href="./php/account.php?method=logout">Logout</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</header>