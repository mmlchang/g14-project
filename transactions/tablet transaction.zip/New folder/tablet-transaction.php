<?php include "./db/db.php";?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Tze Yin Membership Management Portal</title>
    <link rel="stylesheet" href="./fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="./styles/style.css" />
</head>

<body>

    <?php include "./partial/header.php"; ?>

    <div class="main">

        <div class="header-section">
            <h2 class="heading">Tablet Transaction</h2>
            <a href="./add-tablet-transaction.php" class="button button-primary" style="margin-top: 20px;">Add Tablet Transaction</a>


        </div>


        <div style="display: flex;justify-content: center;">

            <form action="./search.php" class="form-1" style="max-width:400px">
                <div class="group">
                    <input name="type" type="hidden" value="Tablet">
                    <input name="keyword" type="text" placeholder="Search transaction by id...">

                </div>
                <div class="group">
                    <button class="button button-red">Search</button>
                </div>
            </form>

        </div>

     

        </div>
    </div>

    <script src="./js/jquery-3.2.1.min.js"></script>

</body>

</html>