<?php include "./db/db.php"; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Tze Yin Membership Management Portal</title>
    <link rel="stylesheet" href="./fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="./styles/style.css" />
</head>

<body>
    
    <?php include "./partial/header.php"; ?>

    <div class="main">

    
        <div class="center-section-1" style="min-height: 300px;margin-top:50px;">
            <div class="center-section-1__container">
                <div class="center-section-1__header">
                    <h2 class="heading">Add New Tablet Transaction</h2>
                    <?php
                    
                        if(isset($_GET["msg"]) && $_GET["msg"] === "added"){
                    
                    ?>  
                    <p style="color:green;">Transaction Added</p>
                    <?php  } ?>
                </div>
                <div class="center-section-1__body">
                    <form class="form-1" action="./php/tablet-transaction.php?method=add" method="POST">
                        <div class="group">
                            <input name="id" type="text" placeholder="Tablet ID" required>
                        </div>
                        <div class="group">
                            <label for="">Installation Date</label>
                            <input name="installdate" type="date" placeholder="" required>
                        </div>
                        <div class="group">
                            <input name="zone" type="text" placeholder="Zone" required>
                        </div>
                        <div class="group">
                            <input name="tier" type="text" placeholder="Tier" required>
                        </div>
                        <div class="group">
                            <input name="row" type="text" placeholder="Row" required>
                        </div>
                      
                       
                        <div class="group">
                            <input name="ancestor" type="text" placeholder="Ancestor Name" required>
                        </div>
                        <div class="group">
                            <input name="price" type="text" placeholder="Price" required>
                        </div>
                        <div class="group">
                            <input name="address" type="text" placeholder="Address" required>
                        </div>
                        
                        <div class="group">
                            <input name="contact1" type="text" placeholder="Contact Number 1:" required>
                        </div>
                        <div class="group">
                            <input name="contact2" type="text" placeholder="Contact Number 2:" required>
                        </div>
                        <div class="group">
                            <label for="">Payment Type</label>
                            <select name="paymenttype">
                                <option value="permanent">Permanent</option>
                                <option value="inatallation">Installation</option>
                            </select>
                        </div>
                        <div class="group">
                            <input name="memberid" type="text" placeholder="Member ID" required>
                        </div>
                        
                        <div class="group">
                            <textarea name="remarks" placeholder="Remarks" required></textarea>
                        </div>
                     
                     
                        <div class="group">
                            <input type="submit" class="button button-primary button-block" value="Save">
                        </div>
                    </form>
                </div>

            </div>
        </div>

       
    </div>
  
    <script src="./js/jquery-3.2.1.min.js"></script>
    
</body>

</html>