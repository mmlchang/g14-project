<?php

include "../db/db.php";

$method = $_GET["method"];

if($method === "add")
{
    global $conn;


    $id = $_POST["id"];
    $installdate = $_POST["installdate"];
    $zone = $_POST["zone"];
    $tier = $_POST["tier"];
    $row = $_POST["row"];
    $ancestor = $_POST["ancestor"];
    $price = $_POST["price"];
    $address = $_POST["address"];
    $contact1 = $_POST["contact1"];
    $contact2 = $_POST["contact2"];
    $paymenttype = $_POST["paymenttype"];
    $memberid = $_POST["memberid"];
    $remarks = $_POST["remarks"];

    $sql = "

        INSERT INTO tablet
        (tablet_id, inst_date, ancestor_name, payment_type, receipt_num, contact_num1, contact_num2, remarks, tablet_zone, tablet_tier, tablet_row, price, address, member_id)
        VALUES
        ('$id','$installdate','$ancestor','$paymenttype','','$contact1','$contact2','$remarks','$zone','$tier','$row','$price','$address','$memberid')
    
    ";
    $result = $conn->query($sql);
   
    header("Location: ../add-tablet-transaction.php?msg=added");

}

if($method === "delete")
{
    global $conn;

    $id = $_GET["id"];
   
   $sql = "
        DELETE FROM tablet WHERE tablet_id = '$id'
    ";
    $result = $conn->query($sql);
    header("Location: ../tablet-transaction.php");
    
   
}


if($method === "update")
{
    global $conn;


    $oldid = $_POST["oldid"];
    $id = $_POST["id"];
    $installdate = $_POST["installdate"];
    $zone = $_POST["zone"];
    $tier = $_POST["tier"];
    $row = $_POST["row"];
    $ancestor = $_POST["ancestor"];
    $price = $_POST["price"];
    $address = $_POST["address"];
    $contact1 = $_POST["contact1"];
    $contact2 = $_POST["contact2"];
    $paymenttype = $_POST["paymenttype"];
    $memberid = $_POST["memberid"];
    $remarks = $_POST["remarks"];

    $sql = "

        UPDATE tablet
        SET tablet_id = '$id', inst_date = '$installdate', ancestor_name = '$ancestor', payment_type = '$paymenttype', receipt_num = '', contact_num1 = '$contact1', contact_num2 = '$contact2', remarks = '$remarks', tablet_zone = '$zone', tablet_tier = '$tier', tablet_row = '$row', price = '$price', address = '$address', member_id = '$memberid'
       WHERE tablet_id = '$oldid'
    
    ";
    $result = $conn->query($sql);
   
   header("Location: ../edit-tablet-transaction.php?id=$oldid&msg=updated");

}



?>