<?php include "./db/db.php"; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Tze Yin Membership Management Portal</title>
    <link rel="stylesheet" href="./fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="./styles/style.css" />
</head>

<body>

    <?php include "./partial/header.php"; ?>

    <div class="main">

        <div class="header-section">
            <h2 class="heading"><?php echo $_GET["type"]; ?> Transaction ID: <?php echo $_GET["keyword"]; ?></h2>



        </div>



        <?php if ($_GET["type"] == "Tablet") { ?>
            <div class="card-container topics-cards">
                <?php

                global $conn;

                $keyword = $_GET['keyword'];
                $sql = "SELECT *FROM tablet WHERE member_id = '$keyword'";
                $result = $conn->query($sql);;

                while ($row = $result->fetch_assoc()) {


                ?>
                    <div class="card flex-center">

                        <ul class="card-list text-center">
                            <li><span>Member ID:</span> <?php echo $row["member_id"]; ?></li>
                            <li><span>Install Date:</span> <?php echo $row["inst_date"]; ?></li>
                            <li><span>Ancestor Name:</span> <?php echo $row["ancestor_name"]; ?></li>


                        </ul>
                        <a href="./view-tablet-transaction.php?id=<?php echo $row["member_id"]; ?>" class="button button-primary button-block card-button" style="text-align: center;">View<i></i></a>
                        <a href="./edit-tablet-transaction.php?id=<?php echo $row["member_id"]; ?>" class="button button-primary button-block card-button" style="text-align: center;">Edit<i></i></a>
                        <a href="./php/tablet-transaction.php?method=delete&id=<?php echo $row["member_id"];  ?>" style="text-align: center;" class="button button-red button-block card-button">Delete<i></i></a>
                    </div>

                <?php } ?>


            </div>
        <?php } ?>

    </div>

    <script src="./js/jquery-3.2.1.min.js"></script>

</body>

</html>