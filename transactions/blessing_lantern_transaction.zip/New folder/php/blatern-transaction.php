<?php

include "../db/db.php";

$method = $_GET["method"];

if($method === "add")
{
    global $conn;


    $id = $_POST["id"];
    $contact = $_POST["contact"];
    $price = $_POST["price"];
    $votive = $_POST["votiveprice"];
	$memberid = $_POST["memberid"];
    $remarks = $_POST["remarks"];

    $sql = "

        INSERT INTO blantern
        (BLantern_id, contact_num, blessing_price, votive_price, member_id, remarks)
        VALUES
        ('$id','$contact','$price','$votive','$memberid','$remarks')
    
    ";
    $result = $conn->query($sql);
   
    header("Location: ../add-blantern-transaction.php?msg=added");

}

if($method === "delete")
{
    global $conn;

    $id = $_GET["id"];
   
   $sql = "
        DELETE FROM blantern WHERE member_id = '$id'
    ";
    $result = $conn->query($sql);
    header("Location: ../blessing-lantren-transaction.php");
    
   
}


if($method === "update")
{
    global $conn;


    $oldid = $_POST["oldid"];
    $id = $_POST["id"];
    $contact = $_POST["contact"];
    $price = $_POST["price"];
    $votive = $_POST["votiveprice"];
	$memberid = $_POST["memberid"];
    $remarks = $_POST["remarks"];

    $sql = "
        UPDATE blantern
        SET BLantern_id = '$id', contact_num = '$contact', blessing_price = '$price', votive_price = '$votive', member_id = '$memberid', remarks = '$remarks'
        WHERE BLantern_id = '$oldid'
    ";
    $result = $conn->query($sql);
   
   header("Location: ../edit-blantern-transaction.php?id=$oldid&msg=updated");

}



?>