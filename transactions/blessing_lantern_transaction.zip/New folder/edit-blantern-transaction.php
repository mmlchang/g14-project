<?php include "./db/db.php"; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Tze Yin Membership Management Portal</title>
    <link rel="stylesheet" href="./fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="./styles/style.css" />
</head>

<body>
    
    <?php include "./partial/header.php"; ?>

    <div class="main">

    
        <div class="center-section-1" style="min-height: 300px;margin-top:50px;">
            <div class="center-section-1__container">
                <div class="center-section-1__header">
                    <h2 class="heading">Edit Blessing Lantern Transaction</h2>
                    <?php
                    
                        if(isset($_GET["msg"]) && $_GET["msg"] === "updated"){
                    
                    ?>  
                    <p style="color:green;">Transaction Updated</p>
                    <?php  } ?>
                </div>
                <div class="center-section-1__body">

                <?php
                    
                    $id = $_GET["id"];

                    global $conn;

                            $sql = "SELECT *FROM blantern WHERE member_id = '$id'";
                            $result = $conn->query($sql);

                            $data = $result->fetch_assoc();

                          
                    ?>


                    <form class="form-1" action="./php/blatern-transaction.php?method=update" method="POST">
                         <input name="oldid" type="hidden" value="<?php echo $id; ?>">
                        <div class="group">
                            <input name="id" type="text" placeholder="ID" required value="<?php echo $data["BLantern_id"]; ?>">
                        </div>
                        <div class="group">
                            <input name="contact" type="text" placeholder="Contact Number" required value="<?php echo $data["contact_num"]; ?>">
                        </div>
                       
                        <div class="group">
                            <input name="price" type="text" placeholder="Price" required value="<?php echo $data["blessing_price"]; ?>">
                        </div>
                        <div class="group">
                            <input name="votiveprice" type="text" placeholder="Votive Price" required value="<?php echo $data["votive_price"]; ?>">
                        </div>
                        <div class="group">
                            <input name="memberid" type="text" placeholder="Member ID" required value="<?php echo $data["member_id"]; ?>" >
                        </div>
                        <div class="group">
                            <textarea name="remarks" placeholder="Remarks" required><?php echo $data["remarks"]; ?></textarea>
                        </div>
                     
                     
                        <div class="group">
                            <input type="submit" class="button button-primary button-block" value="Save">
                        </div>
                    </form>
                </div>

            </div>
        </div>

       
    </div>
  
    <script src="./js/jquery-3.2.1.min.js"></script>
    
</body>

</html>