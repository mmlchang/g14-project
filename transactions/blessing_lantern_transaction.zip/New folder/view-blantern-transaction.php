<?php include "./db/db.php"; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Tze Yin Membership Management Portal</title>
    <link rel="stylesheet" href="./fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="./styles/style.css" />
</head>

<body>

    <?php include "./partial/header.php"; ?>

    <div class="main">

        <div class="header-section">
            <h2 class="heading">B-lantern Transaction</h2>



        </div>





        
            <div class="card-container topics-cards">
            <?php

            global $conn;
            $keyword = $_GET['id'];
            $sql = "SELECT *FROM blantern WHERE member_id = '$keyword'";
            $result = $conn->query($sql);;

            while ($row = $result->fetch_assoc()) {


            ?>
                <div class="card flex-center">

                    <ul class="card-list text-center">
                        <li><span>ID:</span> <?php echo $row["BLantern_id"]; ?></li>

                        <li><span>Contact Number:</span> <?php echo $row["contact_num"]; ?></li>
                        <li><span>Price:</span> <?php echo $row["blessing_price"]; ?></li>
                        <li><span>Votive Price:</span> <?php echo $row["votive_price"]; ?></li>
						<li><span>Member_ID:</span> <?php echo $row["member_id"]; ?></li>
                        <li><span>Remarks:</span> <?php echo $row["remarks"]; ?></li>

                    </ul>
                   
                </div>

       


        </div>


        <?php } ?>

    </div>

    <script src="./js/jquery-3.2.1.min.js"></script>

</body>

</html>