-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 22, 2022 at 03:19 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_mms`
--

-- --------------------------------------------------------

--
-- Table structure for table `blantern`
--

CREATE TABLE `blantern` (
  `BLantern_id` int(10) NOT NULL,
  `contact_num` int(12) NOT NULL,
  `blessing_price` double(10,2) NOT NULL,
  `votive_price` double(10,2) NOT NULL,
  `member_id` varchar(10) NOT NULL,
  `remarks` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- --------------------------------------------------------


--
-- Table structure for table `tablet`
--

CREATE TABLE `tablet` (
  `tablet_id` int(10) NOT NULL,
  `inst_date` varchar(255) DEFAULT NULL,
  `ancestor_name` varchar(20) DEFAULT NULL,
  `payment_type` varchar(20) NOT NULL,
  `receipt_num` int(10) DEFAULT NULL,
  `contact_num1` int(12) DEFAULT NULL,
  `contact_num2` int(12) DEFAULT NULL,
  `remarks` varchar(200) DEFAULT NULL,
  `tablet_zone` varchar(10) DEFAULT NULL,
  `member_id` varchar(10) NOT NULL,
  `tablet_tier` varchar(10) DEFAULT NULL,
  `tablet_row` varchar(10) DEFAULT NULL,
  `price` double(10,2) DEFAULT NULL,
  `address` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------



--
-- Indexes for table `blantern`
--
ALTER TABLE `blantern`
  ADD PRIMARY KEY (`BLantern_id`);

--

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
