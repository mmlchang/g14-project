<?php

session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_MMS";
$conn = new mysqli($servername, $username, $password, $dbname);


if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

return $conn;


function isLoggedIn()
{   
    
    if(isset($_SESSION["username"]) && $_SESSION["username"] !== NULL)
    {
        return true;
    }
    else
    {
        header("Location: ./login.php?msg=login");
    }
}